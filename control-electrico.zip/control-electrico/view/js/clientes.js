
// $(document).ready(function(){

	
// 	$("#selPerfil").select2();
// })

/*=============================================
Data Table
=============================================*/

$(".tablas").DataTable({

	"language": {

		"sProcessing":     "Procesando...",
		"sLengthMenu":     "Mostrar _MENU_ registros",
		"sZeroRecords":    "No se encontraron resultados",
		"sEmptyTable":     "Ningún dato disponible en esta tabla",
		"sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_",
		"sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0",
		"sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
		"sInfoPostFix":    "",
		"sSearch":         "Buscar:",
		"sUrl":            "",
		"sInfoThousands":  ",",
		"sLoadingRecords": "Cargando...",
		"oPaginate": {
		"sFirst":    "Primero",
		"sLast":     "Último",
		"sNext":     "Siguiente",
		"sPrevious": "Anterior"
		},
		"oAria": {
			"sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
			"sSortDescending": ": Activar para ordenar la columna de manera descendente"
		}

	}

});

$(".tablas").on("click", ".btnEditarClient", function(){

	var idCliente = $(this).attr("idCliente");
	window.location = "index.php?ruta=editar-cliente&idCliente="+idCliente;

})

$(".tablas").on("click", ".btnEliminarClient", function() {
	
	var idCliente = $(this).attr("idCliente");
	// console.log("idCliente", idCliente);

});

/*============================
=            ver             =
============================*/

// $(".tablas").on("click", '.btnVer', function(){

// 	var idVer = $(this).attr("idVer");
// 	console.log("idVer", idVer);
	

// })

$(".tablas").on('click', '.btnVer', function() {
	
   var idVisualizacion = $(this).attr("idVer");
   
   var datos = new FormData();
   datos.append("idVisualizacion", idVisualizacion);

   $.ajax({

   	  url:"ajax/gestion.ajax.php",
      method: "POST",
      data: datos,
      cache: false,
      contentType: false,
      processData: false,
      dataType:"json",
      success:function(respuesta){
      	console.log("respuesta", respuesta);
      	
      	var datosUsuario = new FormData();
      	datosUsuario.append("idCliente", respuesta["cliente_id"]);

      	$.ajax({

	   	  url:"ajax/clientes.ajax.php",
	      method: "POST",
	      data: datosUsuario,
	      cache: false,
	      contentType: false,
	      processData: false,
	      dataType:"json",
	      success:function(respuesta) {

	      	console.log("respuesta cliente", respuesta)
	      	$("#nombre").val(respuesta["id"]);
	      	$("#nombre").html(respuesta["nombre"])

	      }

	    });

	    $("#lecturaAnterior").val(respuesta["lectura_anterior"]) 
	    $("#lecturaActual").val(respuesta["lectura_actual"])
	    $("#deuda").val(respuesta["deuda"])
	    $("#totalKls").val(respuesta["totalKws"])
	    $("#energiaActiva").val(respuesta["energia_activa"])
	    $("#subTotal").val(respuesta["subTotal"])
	    $("#igvCalculo").val(respuesta["IgvCalculo"])
	    $("#total").val(respuesta["total"]) 
	    $("#fechaRegistro").val(respuesta["fecha_registro"]) 

      }

   });


});

/*======================================
=            eliminar datos  del cliente          =
======================================*/

$(".tablas").on("click", ".btnEliminarClient", function(){
	var idClienteDelete = $(this).attr("idCliente");
	// console.log("idClienteDelete", idClienteDelete);
	swal({
	    title: '¿Está seguro de borrar el cliente?',
	    text: "¡Si no lo está puede cancelar la accíón!",
	    type: 'warning',
	    showCancelButton: true,
	    confirmButtonColor: '#3085d6',
	      cancelButtonColor: '#d33',
	      cancelButtonText: 'Cancelar',
	      confirmButtonText: 'Si, borrar cliente!'
	  }).then(function(result){

	  	if (result.value) {

	  		 window.location = "index.php?ruta=clientes&idCliente="+idClienteDelete;

	  	}

	  })
})

/*========================================
=            Eliminar gestión            =
========================================*/

$(".tablas").on("click", ".btnTrash", function() {
	
	
	var idM = $(this).attr("idM");
	// console.log("idM", idM);

	swal({
	      title: '¿Está seguro de borrar éste movimiento?',
	      text: "¡Si no lo está puede cancelar la accíón!",
	      type: 'warning',
	      showCancelButton: true,
	      confirmButtonColor: '#3085d6',
	      cancelButtonColor: '#d33',
	      cancelButtonText: 'Cancelar',
	      confirmButtonText: 'Si, borrar movimiento!'
	  }).then(function(result){

	  		if (result.value) {

	  			window.location = "index.php?ruta=gestion-electrica&idM="+idM;

	  		}

	  })

});
