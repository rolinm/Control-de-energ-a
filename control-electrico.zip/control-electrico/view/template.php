<?php 
	
	session_start();

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Control de medida eléctrica</title>
	<!--=====================================
	 Links de css 
	======================================-->
	<link rel="stylesheet" href="view/css/w3-colors-2020.css">
	<link rel="stylesheet" href="view/css/w3-colors-2021.css">
	<link rel="stylesheet" href="view/css/w3-colors-flat.css">
	<link rel="stylesheet" href="view/css/w3-colors-ios.css">
	<link rel="stylesheet" href="view/css/w3-colors-metro.css">
	<link rel="stylesheet" href="view/css/w3-colors-win8.css">
	<link rel="stylesheet" href="view/css/w3.css">

	<!--=====================================
	Datatable Css
	======================================-->
	<link href="https://cdn.datatables.net/v/dt/dt-1.13.4/datatables.min.css" rel="stylesheet"/>

	<!--=====================================
	Plugins select2
	======================================-->
	<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


	<!--=====================================
	Plugins JavaScript
	======================================-->
	<script type="text/javascript" src="view/js/plugins/jquery.min.js"></script>
	<script type="text/javascript" src="view/js/plugins/sweetalert2.all.js"></script>

	<!--=====================================
	Datatable js
	======================================-->
	<script src="https://cdn.datatables.net/v/dt/dt-1.13.4/datatables.min.js"></script>
	<script src="https://kit.fontawesome.com/e632f1f723.js" crossorigin="anonymous"></script>

	<!--=====================================
	Plugins select2 js
	======================================-->
	<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

	<script src="view/js/plugins/number.js"></script>
		
</head>

<body class="w3-light-grey">
	
	<div class="w3-container w3-main">
		
		<?php

		if (isset($_SESSION["iniciarSesion"]) && $_SESSION["iniciarSesion"] == "ok") {

			require "pages/modulos/header.php";

			require "pages/modulos/menu.php";

			if (isset($_GET["ruta"])) {
				
				if ($_GET["ruta"] == "inicio" || 
					$_GET["ruta"] == "usuarios" || 
					$_GET["ruta"] == "gestion-electrica" || 
					$_GET["ruta"] == "clientes" ||
					$_GET["ruta"] == "editar-cliente" ||
					$_GET["ruta"] == "ver" ||
					$_GET["ruta"] == "salir") {
					
					include "pages/".$_GET["ruta"].".php";

				} else {
					
					include "pages/error404.php";

				}

			} else {
				
				include "pages/inicio.php";

			}

		} else {
			
			include "pages/login.php";

		} 
	
	?>
		
	</div>

</body>
<script src="view/js/clientes.js"></script>
</html>