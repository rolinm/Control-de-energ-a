
<div class="w3-container">
	
	<h3 class="">Gestión de clientes</h3>
	<!-- <hr class="w3-third w3-xlarge w3-padding w3-border-indigo"> -->
</div>

<!--=====================================
	botón para registrar usuarios que administren el sistema
======================================-->
<div class="w3-section">
		
	<button class="w3-btn w3-card-4 w3-indigo" onclick="document.getElementById('modalUsuarios').style.display='block'">Registrar nuevo</button>

</div>

<!--=====================================
Modal para registrar usuario
======================================-->

<div id="modalUsuarios" class="w3-modal">
	
	<div class="w3-modal-content w3-card-4 w3-animate-top" style="max-width: 900px">
	
		<div class="w3-container w3-teal">
			
			<h2 class="w3-center">Agregar clientes</h2>

			<span onclick="document.getElementById('modalUsuarios').style.display='none'" class="w3-button w3-hover-red w3-display-topright" title="Cerrar modal">&times;</span>

		</div>

		<form class="w3-container" method="post">
			
			<div class="w3-section">
				
				<div class="w3-row-padding">

					<div class="w3-third">

						<label for="">Nombre cliente</label>

						<input class="w3-input w3-border" type="text" name="registerNameClient" placeholder="Nombre del cliente" required>

					</div>

					<div class="w3-third">
						<label for="">Documento(DNI)</label>
						<input class="w3-input w3-border" type="text" name="registerDocumentClient" placeholder="Número de DNI" required>

					</div>

					<div class="w3-third">
						<label for="">Teléfono</label>
						<input class="w3-input w3-border" type="tel" name="registerTelephoneClient" placeholder="Número de celular" required>

					</div>

					<div class="w3-half">

						<label>Dirección</label>

						<input class="w3-input w3-border" type="text" name="registerDirectionClient" placeholder="Direción" required>

					</div>

					<div class="w3-half">

						<label>Email</label>

						<input class="w3-input w3-border" type="email" name="registerEmailClient" placeholder="Direción de correo electrónico" required>

					</div>				

				</div>

				
				<div class="w3-row-padding">
					
					<hr class="w3-xlarge w3-padding w3-border-indigo">
					
				</div>

				<div class="w3-row-padding">
					
					<div class="w3-third">
						
						<input type="submit" class="w3-btn w3-block w3-blue w3-round" value="Registrar"> 

					</div>

					<div class="w3-third">
						
						<button class="w3-button w3-card-4 w3-round" onclick="document.getElementById('modalUsuarios').style.display='none'">Cancelar</button> 

					</div>

					<?php  

						$clients = new ControllerClients();
						$clients -> ctrRegisterClients();

					?>

				</div>

			</div>	

		</form>

	</div>

</div>

<!--=====================================
Tabla de usuarios
======================================-->

<div class="w3-section  w3-responsive">
	
	<table class="w3-table-all w3-small tablas">
		
		<thead>
			
			<tr class="w3-flat-wet-asphalt">
				
				<th>#</th>
				<th>Nombre</th>
				<th>Documento</th>
				<th>Teléfono</th>
				<th>Direción</th>
				<th>Email</th>
				<th>Fecha de registro</th>
				<th>Acciones</th>

			</tr>

		</thead>

		<tbody>


			<?php

				$item = null;
				$valor = null;

				$listClientes = ControllerClients::ctrShowClients($item, $valor); 
				// echo '<pre>'; print_r($listClientes); echo '</pre>';

				foreach ($listClientes as $key => $value) {
					
					echo '<tr class="w3-hover-pale-red">

							<td>'.($key+1).'</td>

							<td>'.$value["nombre"].'</td>

							<td>'.$value["documento"].'</td>

							<td>'.$value["telefono"].'</td>

							<td>'.$value["direccion"].'</td>

							<td>'.$value["email"].'</td>

							<td>'.$value["fecha_registro"].'</td>

							<td>

								<button class="w3-btn w3-round w3-small w3-card-4  btnEditarClient" idCliente="'.$value["id"].'"><i class="fa fa-pencil"></i></button>

								<button class="w3-btn w3-round w3-small w3-card-4 w3-win8-red btnEliminarClient" idCliente="'.$value["id"].'"><i class="fa fa-trash"></i></button>

							</td>

					</tr>';	

				}

			 ?>

		</tbody>

	</table>

	<?php 

		$eliminarCliente = new ControllerClients();

		$eliminarCliente -> ctrDeleteClient();

	 ?>

</div>
