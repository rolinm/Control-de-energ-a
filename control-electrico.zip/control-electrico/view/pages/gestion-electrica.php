
<!--=====================================
	botón para registrar movimientos
======================================-->
<div class="w3-section">
		
	<button class="w3-btn w3-card-4 w3-indigo  w3-round" onclick="document.getElementById('modalUsuarios').style.display='block'">Registrar <i class="fa fa-plus"></i></button>

</div>

<!--=====================================
Modal para registrar movimientos
======================================-->

<div id="modalUsuarios" class="w3-modal">
	
	<div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width: 900px">
	
		<div class="w3-container w3-indigo">
			
			<h2 class="w3-center">Agregar movimiento</h2>

			<span onclick="document.getElementById('modalUsuarios').style.display='none'" class="w3-button w3-hover-red w3-display-topright" title="Cerrar modal">&times;</span>

		</div>

		<form class="w3-container" method="post">
			
			<div class="w3-section">
				
				<div class="w3-row-padding">

					<div class="w3-third">

						<label for="">Lectura anterior:</label>

						<input class="w3-input w3-border w3-hover-border-black" type="number" step="any" name="lecturaAnterior" placeholder="Ingresar lectura anterior" required min="0">

					</div>

					<div class="w3-third">
						<label for="">Lectura actual:</label>
						<input class="w3-input w3-border w3-hover-border-black" type="number" step="any" name="lecturaActual" placeholder="Ingresar lectura actual" required min="0">

					</div>

					<div class="w3-third">
						<label for="">¿Mantiene una deuda?</label>
						<input class="w3-input w3-border w3-hover-border-black" type="number" step="any" name="cantidadPago" placeholder="Ingresar cantidad a pagar" required min="0">

					</div>

					<div class="w3-half">

						<label>Cliente</label>

						<select name="cliente" id="selPerfil" class="w3-select w3-input w3-border w3-hover-border-black">
							
							<option value="">Selecionar Cliente</option>

							<?php 

								$item = null;
								$valor = null;

								$clientes = ControllerClients::ctrShowClients($item, $valor);
								
								foreach ($clientes as $key => $value) {
									
									echo '<option class="w3-section" value="'.$value["id"].'">'.$value["nombre"].'</option>';

								}


							 ?>

						</select>

					</div>
		

				</div>

				
				<div class="w3-row-padding">
					
					<hr class="w3-xlarge w3-padding w3-border-indigo">
					
				</div>

				<div class="w3-row-padding">
					
					<div class="w3-third">
						
						<input type="submit" class="w3-btn w3-block w3-indigo w3-round" value="Registrar"> 

					</div>

					<div class="w3-third">
						
						<button class="w3-button w3-card-4 w3-round" onclick="document.getElementById('modalUsuarios').style.display='none'">Cancelar</button>

					</div>


					<?php  

						$mantenimiento = new ControladorMantenimiento();

						$mantenimiento -> ctrRegistrarMantenimiento();

					?>

				</div>

			</div>	

		</form>

	</div>

</div>

<!--=====================================
Tabla de usuarios
======================================-->

<div class="w3-section  w3-responsive">
	
	<table class="w3-table-all w3-small tablas">
		
		<thead>
			
			<tr class="w3-flat-wet-asphalt">
				
				<th>#</th>
				<th>Lectura anterior</th>
				<th>Lectura actual</th>
				<th>Deuda</th>
				<th>Cliente</th>
				<th>Accions</th>

			</tr>

		</thead>

		<tbody>


			<?php

				$item = null;

				$valor = null;

				$listadoElectrico = ControladorMantenimiento::ctrMostrarMantenimiento($item, $valor);
				

			 ?>

			 <?php foreach ($listadoElectrico as $key => $value): ?>
			 	
			 	<tr class="w3-hover-pale-red">
			 		
			 		<td><?php echo ($key+1); ?></td>
			 		<td><?php echo $value["lectura_anterior"] ?></td>
			 		<td><?php echo $value["lectura_actual"] ?></td>
			 		<td><?php echo $value["deuda"] ?></td>
			 		<?php 

			 			$item = "id";

			 			$valor = $value["cliente_id"];

			 			$respuestaCliente = ControllerClients::ctrShowClients($item, $valor);

			 		 ?>
			 		<td><?php echo $respuestaCliente["nombre"] ?></td>

			 		<td>

			 			<button class="w3-btn w3-small w3-indigo w3-round btnVer" onclick="document.getElementById('openView').style.display='block'" idVer="<?php echo $value["id"] ?>"><i class="fa fa-eye"></i></button>

			 			<button class="w3-btn w3-red w3-round w3-small btnTrash"><i class="fa fa-trash"></i></button>

			 		</td>

			 	</tr>

			 <?php endforeach ?>

		</tbody>

	</table>

	<?php 

		$eliminarMantenimiento = new ControladorMantenimiento();

		$eliminarMantenimiento -> ctrEliminarMantenimiento();

	 ?>

</div>

<!--=====================================
modal para ver el detalle de los datos
======================================-->

<div id="openView" class="w3-modal">
	
	<div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width: 900px">
	
		<div class="w3-container w3-indigo">
			
			<h2 class="w3-center">Detalles del mantenimiento</h2>

			<span onclick="document.getElementById('openView').style.display='none'" class="w3-button w3-hover-red w3-display-topright" title="Cerrar modal">&times;</span>

		</div>

		<div class="w3-container">

				<p>Detalles Generales <!-- <span id="nombre"></span> --></p>

				<table class="w3-table w3-striped w3-bordered w3-border w3-hoverable w3-white">

					<tbody>

						<tr>

							<td>Nombre del cliente </td>

							<td><span id="nombre"></span></td>

						</tr>

					<tr>

						<td>Lectura anterior</td>

						<td><input id="lecturaAnterior" type="text" readonly class="w3-input w3-border w3-disable"></td>

					</tr>

					<tr>

						<td>Lectura actual</td>

						<td><input id="lecturaActual" type="text" readonly class="w3-input w3-border w3-disable"></td>

					</tr>

					<tr>

						<td>Deuda</td>

						<td><input id="deuda" type="text" readonly class="w3-input w3-border w3-disable"></td>

					</tr>

					<tr>

						<td>Total Kilowas</td>

						<td><input id="totalKls" type="text" readonly class="w3-input w3-border w3-disable"></td>

					</tr>

					<tr>

						<td>Energía activa</td>

						<td><input id="energiaActiva" type="text" readonly class="w3-input w3-border w3-disable"></td>

					</tr>

					<tr>

						<td>Sub Total</td>

						<td><input id="subTotal" type="text" readonly class="w3-input w3-border w3-disable"></td>

					</tr>

					<tr>

						<td>IGV Cálculo</td>

						<td><input id="igvCalculo" type="text" readonly class="w3-input w3-border w3-disable"></td>

					</tr>

					<tr>

						<td>Total</td>

						<td><input id="total" type="text" readonly class="w3-input w3-border w3-disable"></td>

					</tr>

					<tr>

						<td>Fecha de registro</td>

						<td><input id="fechaRegistro" type="text" readonly class="w3-input w3-border w3-disable"></td>

					</tr>

				</tbody>

			</table>

			<br>

		</div>

	</div>

</div>