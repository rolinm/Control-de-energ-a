<div class="w3-section">

  <div class="w3-row-padding w3-margin-bottom">

    <div class="w3-quarter">

      <div class="w3-container w3-flat-green-sea w3-padding-16">

        <div class="w3-left">

          <i class="fa fa-usd w3-xxxlarge"></i>

        </div>

        <div class="w3-right">

          <?php 

            $totalKws = ControladorMantenimiento::ctrSumarTotal();

          ?>

          <h3>S/. <?php echo number_format($totalKws["total"],2); ?></h3>

        </div>

        <div class="w3-clear"></div>

        <h4><a href="gestion-electrica" style="text-decoration: none;">TOTAL</a></h4>

      </div>

    </div>

    <div class="w3-quarter">

      <div class="w3-container w3-flat-belize-hole w3-padding-16">

        <div class="w3-left">

          <i class="fa fa-credit-card w3-xxxlarge"></i>

        </div>

        <div class="w3-right">

          <?php 

          $totalGeneral = ControladorMantenimiento::ctrTotalIgv();

          ?>

          <h3>S/. <?php echo number_format($totalGeneral["total"],2); ?></h3>

        </div>

        <div class="w3-clear"></div>

        <h4><a href="gestion-electrica" style="text-decoration: none;">IGV GENERAL</a></h4>

      </div>

    </div>

    <div class="w3-quarter">

      <div class="w3-container w3-flat-wet-asphalt w3-padding-16">

        <div class="w3-left">

          <i class="fa fa-area-chart w3-xxxlarge"></i>

        </div>

        <div class="w3-right">

          <?php 

          $totalKws = ControladorMantenimiento::ctrSumarTotal();

          ?>

          <h3><?php echo number_format($totalKws["total"],2); ?></h3>

        </div>

        <div class="w3-clear"></div>

        <h4><a href="gestion-electrica" style="text-decoration: none;">TOTAL KILOWAS</a></h4>

      </div>

    </div>

    <div class="w3-quarter">

      <div class="w3-container w3-flat-midnight-blue w3-text-white w3-padding-16">

        <div class="w3-left"><i class="fa fa-thumbs-down w3-xxxlarge"></i></div>

        <div class="w3-right">

          <?php 

          $deuda = ControladorMantenimiento::ctrDeuda();

          ?>

          <h3>S/. <?php echo number_format($deuda["deuda"],2); ?></h3>

        </div>

        <div class="w3-clear"></div>

        <h4><h4><a href="gestion-electrica" style="text-decoration: none;">DEUDA PENDIENTE</a></h4></h4>

      </div>

    </div>

  </div>

</div>