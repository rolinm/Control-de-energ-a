<div class="w3-bar w3-border w3-light-grey">

	<a href="inicio" class="w3-bar-item w3-border-right w3-indigo w3-mobile w3-btn">Inicio</a>

	<a href="usuarios" class="w3-bar-item w3-border-right w3-mobile w3-button">Usuarios</a>

	<a href="clientes" class="w3-bar-item w3-border-right w3-mobile w3-button">Clientes</a>

	<a href="gestion-electrica" class="w3-bar-item w3-border-right  w3-mobile w3-button">Gestión eléctrica</a>

	<a href="salir" class="w3-bar-item w3-border-right w3-red w3-btn w3-right w3-mobile">Salir</a>

</div>