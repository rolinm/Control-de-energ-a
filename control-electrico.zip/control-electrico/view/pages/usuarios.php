
<div class="w3-container">
	
	<h3 class="">Gestión de usuarios</h3>
	<hr class="w3-third w3-xlarge w3-padding w3-border-indigo">

	

</div>

<!--=====================================
	botón para registrar usuarios que administren el sistema
======================================-->
<div class="w3-section">
		
	<button class="w3-btn w3-card-4 w3-indigo w3-round" onclick="document.getElementById('modalUsuarios').style.display='block'">Registrar nuevo <i class="fa fa-plus"></i></button>

</div>

<!--=====================================
Modal para registrar usuario
======================================-->

<div id="modalUsuarios" class="w3-modal">
	
	<div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width: 900px">
		
		<div class="w3-center"><br>
			
			<span onclick="document.getElementById('modalUsuarios').style.display='none'" class="w3-button w3-hover-red w3-display-topright" title="Cerrar modal">&times;</span>

		</div>

		<form class="w3-container" method="post">
			
			<div class="w3-section">
				
				<div class="w3-row-padding">

					<div class="w3-third">

						<label for="">Nombre</label>

						<input class="w3-input w3-border" type="text" name="registerName" placeholder="Nombre" required>

					</div>

					<div class="w3-third">
						<label for="">Usuario</label>
						<input class="w3-input w3-border" type="text" name="registerUsers" placeholder="Usuario" required>

					</div>

					<div class="w3-third">
						<label for="">Password</label>
						<input class="w3-input w3-border" type="password" name="registerPassword" placeholder="Password" required>

					</div>

					<div class="w3-half">

						<label>Correo electrónico</label>

						<input class="w3-input w3-border" type="text" name="registerEmail" placeholder="Emai" required>

					</div>

					<div class="w3-half">

						<label>Perfil</label>

						<select name="selPerfil" id="selPerfil" class="w3-select w3-input w3-border">
							
							<option value="Administrador">Administrador</option>

							<option value="Supervisor">Supervisor</option>

							<option value="Mantenimiento">Mantenimiento</option>

						</select>

					</div>				

				</div>

				
				<div class="w3-row-padding">
					
					<hr class="w3-xlarge w3-padding w3-border-indigo">
					
				</div>

				<div class="w3-row-padding">
					
					<div class="w3-third">
						
						<input type="submit" class="w3-btn w3-block w3-teal" value="Registrar"> 

					</div>

					<?php  

						$registerUsers = new ControllerUsers();

						$registerUsers -> ctrRegisterUsers();

					?>

				</div>

			</div>	

		</form>

	</div>

</div>

<!--=====================================
Tabla de usuarios
======================================-->

<div class="w3-section w3-card w3-responsive">
	
	<table class="w3-table-all w3-small">
		
		<thead>
			
			<tr class="w3-flat-wet-asphalt">
				
				<td>#</td>
				<td>Nombre</td>
				<td>Usuarios</td>
				<td>Email</td>
				<td>Perfil</td>
				<td>Estado</td>
				<td>Último Login</td>
				<td>Fecha de registro</td>

			</tr>

		</thead>

		<tbody>

			<?php 

				$item = null;

				$valor = null;

				$listUsers = ControllerUsers::ctrShowUsers($item, $valor);
				

				foreach ($listUsers as $key => $value) {
					
					echo '<tr class="w3-hover-pale-red">
				
						<td>'.($key+1).'</td>

						<td>'.$value["name"].'</td>

						<td>'.$value["users"].'</td>

						<td>'.$value["email"].'</td>

						<td>'.$value["profile"].'</td>';

						if ($value["estatus"] == 0) {
							
							echo '<td><button class="w3-small w3-btn w3-round w3-red">Desactivado</button></td>';

						} else {
							
							echo '<td><button class="w3-small w3-btn w3-round w3-green">Activo</button></td>';

						}

						

						echo '<td>'.$value["ultimo_login"].'</td>

						<td>'.$value["fecha"].'</td>


					</tr>';

				}

			 ?>

		</tbody>

	</table>

</div>
