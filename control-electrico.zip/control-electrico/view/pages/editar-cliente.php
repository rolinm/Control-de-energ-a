<?php 

	$item = "id";

	$valor = $_GET["idCliente"];

	$clientes = ControllerClients::ctrShowClients($item, $valor);
	// echo '<pre>'; print_r($clientes); echo '</pre>';

 ?>

<div class="w3-container">

	<form class="w3-container" method="post">

		<div class="w3-section">

			<div class="w3-row-padding">

				<div class="w3-third">

					<label for="">Nombre cliente</label>

					<input class="w3-input w3-border" type="text" name="updateNameClient" value="<?php echo $clientes["nombre"] ?>" required>

				</div>

				<div class="w3-third">
					<label for="">Documento(DNI)</label>
					<input class="w3-input w3-border" type="text" name="updateDocumentClient" value="<?php echo $clientes["documento"] ?>" required>

				</div>

				<div class="w3-third">
					<label for="">Teléfono</label>
					<input class="w3-input w3-border" type="tel" name="updateTelephoneClient" value="<?php echo $clientes["telefono"] ?>" required>

				</div>

				<div class="w3-half">

					<label>Dirección</label>

					<input class="w3-input w3-border" type="text" name="updateDirectionClient" value="<?php echo $clientes["direccion"] ?>" required>

				</div>

				<div class="w3-half">

					<label>Email</label>

					<input class="w3-input w3-border" type="email" name="updateEmailClient" value="<?php echo $clientes["email"] ?>" required>

					<input type="hidden" name="idCliente" value="<?php echo $clientes["id"] ?>">

				</div>				

			</div>


			<div class="w3-row-padding">

				<hr class="w3-xlarge w3-padding w3-border-indigo">

			</div>

			<div class="w3-row-padding">

				<div class="w3-third">

					<input type="submit" class="w3-btn w3-indigo w3-mobile w3-round" value="Actualizar registro">

					<a href="clientes" class="w3-btn w3-round w3-mobile w3-card-4 w3-red">Regresar <i class=""></i></a> 

				</div>

				<?php  

				$clients = new ControllerClients();
				$clients -> ctrUpdateClients();

				?>

			</div>

		</div>	

	</form>

</div>