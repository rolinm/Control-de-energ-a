<div class="w3-container">
		
	<div class="w3-section">
		
		<ul class="w3-ul w3-border w3-half" id="contenedor">

			<?php 

				$fecha = date('Y-m');

			 ?>

			<li class=""><h2 class="">DETALLES DE CONSUMO ELÉCTRICO <span class=""><?php echo $fecha; ?></span></h2></li>

			<?php 

				$item = "id";

				$valor = $_GET["idElet"];

				$detalles = ControladorMantenimiento::ctrMostrarMantenimiento($item, $valor);
				// echo '<pre>'; print_r($detalles); echo '</pre>';

				date_default_timezone_set('America/Lima');

				// $now = date('Y-m-d H:i:s');

				$fechaInicial = $detalles["fecha_registro"];

				$fecha_venicimiento = strtotime('+1 month', strtotime($fechaInicial));
				
				$vencimiento = date("Y-m-d", $fecha_venicimiento);

				echo '<li class="w3-metro-darken">FECHA DE REGISTRO :'.$detalles["fecha_registro"].' <span class="w3-right w3-text-red">Fecha de vencimiento : '.$vencimiento.'</span></li>
					  <li class="">Lectura anterior :'.$detalles["lectura_anterior"].'</li>
					  <li class="">Lectura actual :'.$detalles["lectura_actual"].'</li>
					  <li>Deuda :'.$detalles["deuda"].'</li>';

					  $item = "id";
					  $valor = $detalles["cliente_id"];

					  $clientes = ControllerClients::ctrShowClients($item, $valor);

					  echo'<li>Cliente : '.$clientes["nombre"].'</li>
					  <li>Total Kilowas : '.$detalles["totalKws"].'</li>
					  <li>Total Energía activa :'.$detalles["energia_activa"].'</li>
					  <li>Sub Total :'.$detalles["subTotal"].'</li>
					  <li>IGV :'.$detalles["IgvCalculo"].'</li>
					  <li class="w3-metro-teal">Total :'.$detalles["total"].'</li>';



			 ?>

			 <div class="w3-section">
			 	
			 	<div class="w3-third">

			 		<button class="w3-btn w3-block w3-flat-turquoise w3-round" id="crearpdf">Imprimir <i class="fa fa-print"></i></button>

			 	</div>

			 	<div class="w3-third w3-container">

			 		<a href="gestion-electrica" class="w3-button w3-card-4 w3-round w3-red">Regresar <i class="fa fa-arrow-circle-left"></i></a> 

			 	</div>

			 </div>

			
		</ul>


	</div>

</div>