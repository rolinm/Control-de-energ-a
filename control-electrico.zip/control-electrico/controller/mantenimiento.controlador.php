<?php

class ControladorMantenimiento {

	/*==============================================================
	=            Registrar nuevos movimiento eléctricos            =
	==============================================================*/
	
	static public function ctrRegistrarMantenimiento() {

		if (isset($_POST["lecturaAnterior"])) {
			
			$lecturaAnteior = $_POST["lecturaAnterior"];

			$lecturaActual = $_POST["lecturaActual"];

			$deudaAnterior = $_POST["cantidadPago"];

			$totalSumaKws = $lecturaActual - $lecturaAnteior;

			$totalKws = number_format($totalSumaKws, 2, '.', '');

			// echo $totalKws;

			/*=====================================================================================
			=            Creamos variables constantes para hacer calculos mantemáticos            =
			=====================================================================================*/
			
			$opc = 0.98;

			$cargoFacturacion = 1.6;

			$alumbradoPublico = 1;

			$Igv = 0.18;

			$totalEnergiaActiva = $totalKws * $opc;

			$energiaActiva = number_format($totalEnergiaActiva, 2, '.', '');

			// echo $energiaActiva;

			/*==============================================
			=            Calculamos el subTotal            =
			==============================================*/
			
			$operacionSubTotal = $energiaActiva + $cargoFacturacion + $alumbradoPublico;

			$subTotal = number_format($operacionSubTotal, 2, '.', '');

			// echo $subTotal;
			
			
			/*=========================================
			=            Calculamos el Igv            =
			=========================================*/
			
			$IgvCalculo = $subTotal * $Igv;

			$totalIgvCalculo = number_format($IgvCalculo, 2, '.', '');

			// echo $totalIgvCalculo;

			/*===========================================
			=            Calculamos el total            =
			===========================================*/
			
			$totalGeneral = $subTotal + $totalIgvCalculo + $deudaAnterior;

			$total = number_format($totalGeneral, 2, '.', '');


			$tabla = "mto_table";

			$datos = array("lectura_anterior" => $_POST["lecturaAnterior"],
				           "lectura_actual" => $_POST["lecturaActual"],
				           "deuda" => $_POST["cantidadPago"],
				           "cliente_id" => $_POST["cliente"],
				           "totalKws" => $totalKws,
				           "energia_activa" => $energiaActiva,
				           "subTotal" => $subTotal,
				           "IgvCalculo" => $totalIgvCalculo,
				           "total" => $total);

			$respuesta = ModeloMantenimientoElectrico::mdlRegistrarMantenimiento($tabla, $datos);

			if ($respuesta == "ok") {
				
				echo'<script>

					swal({
						  type: "success",
						  title: "Un nuevo registro ha sido guardado correctamente",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){

							if (result.value) {

								window.location = "gestion-electrica";

							}
					})

				</script>';

			}
			

		}

	}
	
	/*======================================================================
	=            Mostrar el calculo del mantenimiento electrico            =
	======================================================================*/
	
	static public function ctrMostrarMantenimiento($item, $valor) {

		$tabla = "mto_table";

		$respuesta = ModeloMantenimientoElectrico::mdlMostrarMantenimientoElectrico($tabla, $item, $valor);

		return $respuesta;

	}
	
	/*=================================
	=            Sumar kws            =
	=================================*/
	
	static public function ctrSumarTotal() {

		$tabla = "mto_table";

		$respuesta = ModeloMantenimientoElectrico::mdlMostrarSumaVentas($tabla);

		return $respuesta;

	}
	
	static public function ctrTotal() {

		$tabla = "mto_table";

		$respuesta = ModeloMantenimientoElectrico::mdlMostrarSumaTotal($tabla);

		return $respuesta;

	}

	static public function ctrTotalIgv() {

		$tabla = "mto_table";

		$respuesta = ModeloMantenimientoElectrico::mdlMostrarIgv($tabla);

		return $respuesta;

	}

	/*===============================================
	=            calcular monto en deuda            =
	===============================================*/
	
	static public function ctrDeuda() {

		$tabla = "mto_table";

		$respuesta = ModeloMantenimientoElectrico::mdlDeuda($tabla);

		return $respuesta;

	}
	
	/*======================================
	=            sumar clientes            =
	======================================*/
	
	static public function ctrTotalClientes() {

		$tabla = "clientes";

		$respuesta = ModeloMantenimientoElectrico::mdlTotalClientes($tabla);

		return $respuesta;

	}

	/*======================================
	=            Eliminar datos            =
	======================================*/
	
	static public function ctrEliminarMantenimiento() {

		if (isset($_GET["idM"])) {
			
			$tabla = "mto_table";

			$datos = $_GET["idM"];

			$respuesta = ModeloMantenimientoElectrico::mdlEliminarMantenimiento($tabla, $datos);

			if ($respuesta == "ok") {
				
				echo'<script>

					swal({
						  type: "success",
						  title: "El mantenimiento se ha eliminado correctamente",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){

							if (result.value) {

								window.location = "gestion-electrica";

							}
					})

				</script>';

			}

		}

	}
	
	
}