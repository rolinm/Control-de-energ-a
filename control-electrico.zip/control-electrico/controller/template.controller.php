<?php

class ControllerTemplate {

	public function ctrGetTemplate() {

		include "view/template.php";

	}

}