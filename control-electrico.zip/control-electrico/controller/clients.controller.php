<?php

class ControllerClients {

	/*===========================================
	=            Register of clients            =
	===========================================*/
	
	static public function ctrRegisterClients() {

		if (isset($_POST["registerNameClient"])) {
			
			if (preg_match('/^[a-zA-ZñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["registerNameClient"]) && 
				preg_match('/^[0-9]+$/', $_POST["registerDocumentClient"]) && 
				preg_match('/^[0-9]+$/', $_POST["registerTelephoneClient"]) &&
				preg_match('/^[#\.\-a-zA-Z0-9 ]+$/', $_POST["registerDirectionClient"]) &&
				preg_match('/^[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}$/', $_POST["registerEmailClient"])) {
				

				$table = "clientes";

				$data = array("nombre" => $_POST["registerNameClient"],
					          "documento" => $_POST["registerDocumentClient"],
					          "telefono" => $_POST["registerTelephoneClient"],
					          "direccion" => $_POST["registerDirectionClient"],
					          "email" => $_POST["registerEmailClient"]);

				$respuesta = ClientsModel::mdlRegisterClients($table, $data);

				if ($respuesta == "ok") {
					
					echo'<script>

					swal({
						  type: "success",
						  title: "El cliente ha sido guardado correctamente",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){

							if (result.value) {

								window.location = "clientes";

							}
					})

					</script>';

				}

			} else {
				
				echo'<script>

					swal({
						  type: "error",
						  title: "¡El cliente no puede ir vacío o llevar caracteres especiales!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "clientes";

							}
						})

			  	</script>';

			}

		}

	}
	

	/*=========================================
	=            Show list clients            =
	=========================================*/
	
	static public function ctrShowClients($item, $valor) {

		$table = "clientes";

		$respuesta = ClientsModel::mdlShowClients($table, $item, $valor);

		return $respuesta;

	}
	

	/*======================================================
	=            Update the clients of database            =
	======================================================*/
	
	static public function ctrUpdateClients() {

		if (isset($_POST["updateNameClient"])) {
			
			if (preg_match('/^[a-zA-ZñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["updateNameClient"]) && 
				preg_match('/^[0-9]+$/', $_POST["updateDocumentClient"]) &&
				preg_match('/^[0-9]+$/', $_POST["updateTelephoneClient"]) &&
				preg_match('/^[#\.\-a-zA-Z0-9 ]+$/', $_POST["updateDirectionClient"]) &&
				preg_match('/^[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}$/', $_POST["updateEmailClient"])) {
				
				$table = "clientes";

				$data = array("id" => $_POST["idCliente"],
							  "nombre" => $_POST["updateNameClient"],
							  "documento" => $_POST["updateDocumentClient"],
							  "telefono" => $_POST["updateTelephoneClient"],
							  "direccion" => $_POST["updateDirectionClient"],
							  "email" => $_POST["updateEmailClient"]);

				$respuesta = ClientsModel::mdlUpdateClients($table, $data);

				if ($respuesta == "ok") {
					
					echo'<script>

						swal({
							  type: "success",
							  title: "El cliente ha sido actualizado correctamente",
							  showConfirmButton: true,
							  confirmButtonText: "Cerrar"
							  }).then(function(result){

								if (result.value) {

									window.location = "clientes";

								}
						})

					</script>';

				}

			} else {
				
				echo'<script>

					swal({
						  type: "error",
						  title: "¡El cliente no puede ir vacío o llevar caracteres especiales!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "clientes";

							}
						})

			  	</script>';


			}

		}

	}

	/*============================================================
	=            Eliminar cliente de la base de datos            =
	============================================================*/
	
	static public function ctrDeleteClient() {

		if (isset($_GET["idCliente"])) {
			
			$tabla = "clientes";

			$datos = $_GET["idCliente"];

			$respuesta = ClientsModel::mdlDeleteClient($tabla, $datos);
			echo '<pre>'; print_r($respuesta); echo '</pre>';

			if ($respuesta == "ok") {
				
				echo'<script>

						swal({
							  type: "success",
							  title: "El cliente ha sido eliminado correctamente",
							  showConfirmButton: true,
							  confirmButtonText: "Cerrar"
							  }).then(function(result){

								if (result.value) {

									window.location = "clientes";

								}
						})

					</script>';

			}

		}

	}
	
	
}