<?php

class ControllerUsers {

	public function ctrRegisterUsers() {

		if (isset($_POST["registerName"])) {

			if (preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["registerName"]) &&
				preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["registerUsers"]) &&
				preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["registerPassword"]) &&
				preg_match('/^[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}$/', $_POST["registerEmail"])) {

				$table= "users";

				$encriptar = crypt($_POST["registerPassword"], '$2a$07$asxx54ahjppf45sd87a5a4dDDGsystemdev$');

				$data = array("name" => $_POST["registerName"],
					          "users" => $_POST["registerUsers"],
					          "password" => $encriptar,
					          "email" => $_POST["registerEmail"],
					          "profile" => $_POST["selPerfil"]);

				$respuesta = UsersModel::mdlRegisterUsers($table, $data);

				if ($respuesta == "ok") {
					
					echo'<script>

					swal({
						  type: "success",
						  title: "El usuario ha sido guardado correctamente",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){

							if (result.value) {

								window.location = "usuarios";

							}
					})

					</script>';

				}
				
			} else {
				
				echo'<script>

					swal({
						  type: "error",
						  title: "¡El usuario no puede ir vacío o llevar caracteres especiales!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "usuarios";

							}
						})

			  	</script>';

			}

		}

	}

	/*======================================================
	=            INGRESO DE USUARIOS AL SISTEMA            =
	======================================================*/
	
	static public function ctrIngresoUsuarios() {

		if (isset($_POST["ingUsuario"])) {
			
			if (preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["ingUsuario"])) {
				
				$encriptar = crypt($_POST["ingPassword"], '$2a$07$asxx54ahjppf45sd87a5a4dDDGsystemdev$');

				$table = "users";

				$item = "users";

				$valor = $_POST["ingUsuario"];

				$respuesta = UsersModel::mdlShowUsers($table, $item, $valor);
				// echo '<pre>'; print_r($respuesta); echo '</pre>';

				if (is_array($respuesta)) {
					
					if ($respuesta["users"] == $_POST["ingUsuario"] && $respuesta["password"] == $encriptar) {
						
						/*==================================================================
						=            comprobamos que los usuarios estén activos            =
						==================================================================*/
						
						if ($respuesta["estatus"] == 1) {
							
							/*==================================================
							=            le damos acceso al sistema            =
							==================================================*/
							
							$_SESSION["iniciarSesion"] = "ok";
							$_SESSION["id"] = $respuesta["id"];
							$_SESSION["name"] = $respuesta["name"];
							$_SESSION["users"] = $respuesta["users"];
							$_SESSION["profile"] = $respuesta["profile"];

							/*==================================================================
							=            Registrar fecha para saber el último login            =
							==================================================================*/
							
							date_default_timezone_set('America/Lima');

							$fecha = date('Y-m-d');
							$hora = date('H:i:s');

							$fechaActual = $fecha.' '.$hora;

							$item1 = "ultimo_login";
							$valor1 = $fechaActual;

							$item2 = "id";
							$valor2 = $respuesta["id"];

							$ultimoLogin =  UsersModel::mdlActualizarUsuario($table, $item1, $valor1, $item2, $valor2);

							if ($ultimoLogin == "ok") {
								
								echo '<script>

										window.location = "inicio";

								</script>';

							}
							

						} else {
							
							echo '<div class="w3-panel w3-red">
								 	<h3>HUBO UN ERROR!</h3>
								 	<p>El usuario no está activado en el sistema.</p>
								 </div>';		

						}
						

					} else {
						
						echo '<div class="w3-panel w3-red">
							 	<h3>ERROR!</h3>
							 	<p>El usuario o contraseña no coincide, vuelve a intentarlo.</p>
							 </div>';	

					}

				} else {
						
					echo '<div class="w3-panel w3-red">
						 	<h3>ERROR!</h3>
						 	<p>Hubo un error en el servidor.</p>
						 </div>';	

				}

			} else {
				
				echo'<script>

					swal({
						  type: "error",
						  title: "¡El usuario no puede ir vacío o llevar caracteres especiales!",
						  showConfirmButton: true,
						  confirmButtonText: "Cerrar"
						  }).then(function(result){
							if (result.value) {

							window.location = "usuarios";

							}
						})

			  	</script>';

			}

		}

	}
	

	/*=============================
	 Show list users of database
	===============================*/
	
	static public function ctrShowUsers($item, $valor) {

		$table = "users";

		$respuesta = UsersModel::mdlShowUsers($table, $item, $valor);

		return $respuesta;

	}
	

}