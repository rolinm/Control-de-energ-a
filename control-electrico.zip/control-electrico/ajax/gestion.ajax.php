<?php

require_once "../controller/mantenimiento.controlador.php";
require_once "../model/mantenimiento.modelo.php";

class ajaxGestion {

	public $idVisualizacion;

	public function ajaxVerDetalle() {

		$item = "id";
		$valor = $this->idVisualizacion;

		$respuesta = ControladorMantenimiento::ctrMostrarMantenimiento($item, $valor);

		echo json_encode($respuesta);	

	}

}

/*=============================================
se dispara el método para ver los detalles
=============================================*/

if (isset($_POST["idVisualizacion"])) {
	
	$ver = new ajaxGestion();
	$ver -> idVisualizacion = $_POST["idVisualizacion"];
	$ver -> ajaxVerDetalle();

}