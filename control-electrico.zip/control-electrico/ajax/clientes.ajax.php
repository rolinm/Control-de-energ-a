<?php

require_once "../controller/clients.controller.php";
require_once "../model/clients.model.php";

class ajaxClientes {

	public $idCliente;

	public function ajaxClienteVer() {

		$item = "id";
		$valor = $this->idCliente;

		$respuesta = ControllerClients::ctrShowClients($item, $valor);

		echo json_encode($respuesta);	

	}

}

/*=============================================
se dispara el método para ver los detalles
=============================================*/

if (isset($_POST["idCliente"])) {
	
	$verClientes = new ajaxClientes();
	$verClientes -> idCliente = $_POST["idCliente"];
	$verClientes -> ajaxClienteVer();

}