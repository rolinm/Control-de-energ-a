<?php

require_once "controller/template.controller.php";

/*=================================================
=            Controllers general users            =
=================================================*/

require_once "controller/users.controller.php";
require_once "model/users.model.php";

/*=============================================
=            Controllers general clients             =
=============================================*/

require_once "controller/clients.controller.php";
require_once "model/clients.model.php";

/*===========================================================
=            Controladores del gestir de energía            =
===========================================================*/

require_once "controller/mantenimiento.controlador.php";
require_once "model/mantenimiento.modelo.php";


$plantilla = new ControllerTemplate();
$plantilla -> ctrGetTemplate();