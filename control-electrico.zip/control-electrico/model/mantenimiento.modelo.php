<?php

require_once "conexion.php";

class ModeloMantenimientoElectrico {

	/*===============================================================
	=            Registramos el nuevo registro calculado            =
	===============================================================*/
	
	static public function mdlRegistrarMantenimiento($tabla, $datos) {

		$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(lectura_anterior, lectura_actual, deuda, cliente_id, totalKws, energia_activa, subTotal, IgvCalculo, total)VALUES(:lectura_anterior, :lectura_actual, :deuda, :cliente_id, :totalKws, :energia_activa, :subTotal, :IgvCalculo, :total)");

		$stmt -> bindParam(":lectura_anterior", $datos["lectura_anterior"], PDO::PARAM_STR);
		$stmt -> bindParam(":lectura_actual", $datos["lectura_actual"], PDO::PARAM_STR);
		$stmt -> bindParam(":deuda", $datos["deuda"], PDO::PARAM_STR);
		$stmt -> bindParam(":cliente_id", $datos["cliente_id"], PDO::PARAM_STR);
		$stmt -> bindParam(":totalKws", $datos["totalKws"], PDO::PARAM_STR);
		$stmt -> bindParam(":energia_activa", $datos["energia_activa"], PDO::PARAM_STR);
		$stmt -> bindParam(":subTotal", $datos["subTotal"], PDO::PARAM_STR);
		$stmt -> bindParam(":IgvCalculo", $datos["IgvCalculo"], PDO::PARAM_STR);
		$stmt -> bindParam(":total", $datos["total"], PDO::PARAM_STR);

		if ($stmt->execute()) {
			
			return "ok";

		} else {
			
			return print_r(Conexion::conectar()->errorInfo());

		}

		$stmt -> close();

		$stmt = null;

	}
	
	/*==========================================================
	=            Mostrar el mantenimiento electrico            =
	==========================================================*/
	
	static public function mdlMostrarMantenimientoElectrico($tabla, $item, $valor) {

		if ($item != null && $valor != null) {
			
			$stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $item = :$item");

			$stmt -> bindParam(":".$item, $valor, PDO::PARAM_STR);

			$stmt->execute();

			return $stmt->fetch();

		} else {
			
			$stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla");

			$stmt->execute();

			return $stmt->fetchAll();

		}

		$stmt -> close();

		$stmt = null;

	}
	
	/*==================================
	=            sumar tkws            =
	==================================*/
	
	static public function mdlMostrarSumaVentas($tabla) {

		$stmt = Conexion::conectar()->prepare("SELECT SUM(totalKws) as total FROM $tabla");

		$stmt -> execute();

		return $stmt -> fetch();

		$stmt -> close();

		$stmt = null;

	}

	static public function mdlMostrarSumaTotal($tabla) {

		$stmt = Conexion::conectar()->prepare("SELECT SUM(total) as total FROM $tabla");

		$stmt -> execute();

		return $stmt -> fetch();

		$stmt -> close();

		$stmt = null;

	}
	
	static public function mdlMostrarIgv($tabla) {

		$stmt = Conexion::conectar()->prepare("SELECT SUM(IgvCalculo) as total FROM $tabla");

		$stmt -> execute();

		return $stmt -> fetch();

		$stmt -> close();

		$stmt = null;

	}

	static public function mdlDeuda($tabla) {

		$stmt = Conexion::conectar()->prepare("SELECT SUM(deuda) as deuda FROM $tabla");

		$stmt -> execute();

		return $stmt -> fetch();

		$stmt -> close();

		$stmt = null;

	}

	static public function mdlTotalClientes($tabla) {

		$stmt = Conexion::conectar()->prepare("SELECT count(*) AS clientes FROM $tabla");

		$stmt -> execute();

		return $stmt -> fetch();

		$stmt -> close();

		$stmt = null;

	}

	/*======================================
	=            Eliminar datos            =
	======================================*/
	
	static public function mdlEliminarMantenimiento($tabla, $datos) {

		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");

		$stmt -> bindParam(":id", $datos, PDO::PARAM_INT);

		if ($stmt->execute()) {
			
			return "ok";

		} else {
			
			return print_r(Conexion::conectar()->errorInfo());

		}

		$stmt -> close();

		$stmt = null;

	}
	

}