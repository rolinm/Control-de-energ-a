<?php

require_once "conexion.php";

class  ClientsModel {

	/*================================================
	=            Register one naw clients            =
	================================================*/
	
	static public function mdlRegisterClients($table, $data) {

		$stmt = Conexion::conectar()->prepare("INSERT INTO $table(nombre, documento, telefono, direccion, email)VALUES(:nombre, :documento, :telefono, :direccion, :email)");

		$stmt -> bindParam(":nombre", $data["nombre"], PDO::PARAM_STR);
		$stmt -> bindParam(":documento", $data["documento"], PDO::PARAM_STR);
		$stmt -> bindParam(":telefono", $data["telefono"], PDO::PARAM_STR);
		$stmt -> bindParam(":direccion", $data["direccion"], PDO::PARAM_STR);
		$stmt -> bindParam(":email", $data["email"], PDO::PARAM_STR);

		if ($stmt->execute()) {
			
			return "ok";

		} else {
			
			return print_r(Conexion::conectar()->errorInfo());

		}

		$stmt -> close();

		$stmt = null;

	}	

	/*=========================================
	=            Show list Clients            =
	=========================================*/
	
	static public function mdlShowClients($table, $item, $valor) {

		if ($item != null && $valor != null) {
			
			$stmt = Conexion::conectar()->prepare("SELECT * FROM $table WHERE $item = :$item");

			$stmt -> bindParam(":".$item, $valor, PDO::PARAM_STR);

			$stmt->execute();

			return $stmt->fetch();

		} else {
			
			$stmt = Conexion::conectar()->prepare("SELECT * FROM $table");

			$stmt->execute();

			return $stmt->fetchAll();	

		}

		$stmt -> close();

		$stmt = null;
		
	}
	
	/*======================================
	=            Update clients            =
	======================================*/
	
	static public function mdlUpdateClients($table, $data) {

		$stmt = Conexion::conectar()->prepare("UPDATE $table SET nombre = :nombre, documento = :documento, telefono = :telefono, direccion = :direccion, email = :email WHERE id = :id");

		$stmt -> bindParam(":nombre", $data["nombre"], PDO::PARAM_STR);
		$stmt -> bindParam(":documento", $data["documento"], PDO::PARAM_STR);
		$stmt -> bindParam(":telefono", $data["telefono"], PDO::PARAM_STR);
		$stmt -> bindParam(":direccion", $data["direccion"], PDO::PARAM_STR);
		$stmt -> bindParam(":email", $data["email"], PDO::PARAM_STR);
		$stmt -> bindParam(":id", $data["id"], PDO::PARAM_STR);

		if ($stmt->execute()) {
			
			return "ok";

		} else {
			
			return print_r(Conexion::conectar()->errorInfo());

		}

		$stmt -> close();

		$stmt = null;

	}
	
	/*============================================================
	=            Eliminar cliente de la base de datos            =
	============================================================*/
	
	static public function mdlDeleteClient($tabla, $datos) {

		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");

		$stmt -> bindParam(":id", $datos, PDO::PARAM_INT);

		if ($stmt->execute()) {
			
			return "ok";

		} else {
				
			return print_r(Conexion::conectar()->errorInfo());

		}

		$stmt -> close();

		$stmt = null;

	}
	

}