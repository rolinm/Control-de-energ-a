<?php

require_once "conexion.php";

class UsersModel {

	/*===================================================
	=            this register one new users            =
	===================================================*/
	
	static public function mdlRegisterUsers($table, $data) {

		$stmt = Conexion::conectar()->prepare("INSERT INTO $table(name, users, password, email, profile) VALUES(:name, :users, :password, :email, :profile)");

		$stmt -> bindParam(":name", $data["name"], PDO::PARAM_STR);
		$stmt -> bindParam(":users", $data["users"], PDO::PARAM_STR);
		$stmt -> bindParam(":password", $data["password"], PDO::PARAM_STR);
		$stmt -> bindParam(":email", $data["email"], PDO::PARAM_STR);
		$stmt -> bindParam(":profile", $data["profile"], PDO::PARAM_STR);
		if ($stmt->execute()) {
			
			return "ok";

		} else {
			
			return print_r(Conexion::conectar()->errorInfo());

		}

		$stmt -> close();

		$stmt = null;

	}
	
	/*================================================
	=            Show all register useres            =
	================================================*/
	
	static public function mdlShowUsers($table, $item, $valor) {

		if ($item != null && $valor != null) {
			
			$stmt = Conexion::conectar()->prepare("SELECT * FROM $table WHERE $item = :$item");

			$stmt -> bindParam(":".$item, $valor, PDO::PARAM_STR);

			$stmt->execute();

			return $stmt->fetch();

		} else {
			
			$stmt = Conexion::conectar()->prepare("SELECT * FROM $table");

			$stmt->execute();

			return $stmt->fetchAll();	

		}

		$stmt -> close();

		$stmt = null;

	}

	/*========================
		Activar usuarios  
	========================*/
		
	static public function mdlActualizarUsuario($table, $item1, $valor1, $item2, $valor2) {

		$stmt = Conexion::conectar()->prepare("UPDATE $table SET $item1 = :$item1 WHERE $item2 = :$item2");

		$stmt -> bindParam(":".$item1, $valor1, PDO::PARAM_STR);
		$stmt -> bindParam(":".$item2, $valor2, PDO::PARAM_STR);

		if($stmt -> execute()){

			return "ok";
		
		}else{

			return print_r(Conexion::conectar()->errorInfo());

		}

		$stmt -> close();

		$stmt = null;

	}	
			
}